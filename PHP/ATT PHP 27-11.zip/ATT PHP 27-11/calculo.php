<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css.css">
</head>
<body>
<?php
    if(isset($_POST['submit'])){
    $nome = $_POST['nome_usuario'];
    $diaNascimento = $_POST['dia_nasc'];
    $mesNascimento = $_POST['mes_nasc'];
    $anoNascimento = intval($_POST['ano_nasc']);
    $dia_atual = intval(date('d'));   
    $mes_atual = date('m');   
    $ano_atual = intval(date('a'));   
    }

    

   $anoV = $ano_atual - $anoNascimento;
   
   $anoB = floor($anoV / 4);
   
   $diasV = ($anoV * 365) + $anoB;

   $diasV = ($diasV + ($mes_atual * 30) + $dia_atual);

   $diasV *= -1; 

   echo  "<div id='caixa_principal'>
   <h1>" .$nome ." você viveu " . $diasV ." dias</h1>
        </div>";


?>
</body>
</html>
