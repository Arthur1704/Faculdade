<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Calculo</title>
    <link rel="stylesheet" href="css.css";>
	</head>
	<body>
		<div id="caixa_principal">
			<h2>Dias Vividos</h2>
			<form action="calculo.php" method="POST">
				<label for="nome">Nome:</label><br>
				<input type="text" name="nome_usuario" id="nome">
				<br>
				<label>Dia Nacimento:</label><br>
				<input type="number" name="dia_nasc" class="data">
				<br>
				<label>Mes Nacimento:</label><br>
				<input type="number" name="mes_nasc" class="data">
				<br>
				<label>Ano Nacimento:</label><br>
				<input type="number" name="ano_nasc" class="data">
				<br>
				<input type="submit" name="submit" id="submit">	
			</form>
		<div>	
	</body>
</html>