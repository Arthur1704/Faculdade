package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txtResul = findViewById(R.id.txtValor);
        TextView txtTipo = findViewById(R.id.txtTipo);
        TextView txtLitros = findViewById(R.id.txtLitros);
        TextView txtMarca = findViewById(R.id.txtMarca);

        SharedPreferences prefs = getSharedPreferences("dados", MODE_PRIVATE);

        String combustivel = prefs.getString("combustivel", "...");
        String litrosText = prefs.getString("litros", "...");
        String marca = prefs.getString("marcaCarro", "...");

        double litros = Double.parseDouble(litrosText);

        double valor = 0;

        if (combustivel.equalsIgnoreCase("Gasolina")){
            valor = litros * 6.50;
        }
        else if (combustivel.equalsIgnoreCase("Alcool")){
            valor = litros * 4.65;
        }
        else{
            valor = litros * 7.00;
        }

        //falta colocar nos txt

        txtMarca.setText(marca);
        txtTipo.setText(combustivel);
        txtLitros.setText(litrosText);
        txtResul.setText(String.format("%.2f", valor));




    }
}