package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnEnviar = findViewById(R.id.btn_Enviar);
        Spinner lista = findViewById(R.id.spnMarca);
        RadioGroup rgCombustivel = findViewById(R.id.goupCombus);
        EditText edtLitros = findViewById(R.id.edtLitros);




        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!edtLitros.getText().toString().trim().isEmpty() && (lista.getSelectedItemPosition() != 0) && rgCombustivel.getCheckedRadioButtonId() != -1){

                    int idRadioButton = rgCombustivel.getCheckedRadioButtonId();
                    RadioButton rbCombustivel= findViewById(idRadioButton);

                    String combustivel = rbCombustivel.getText().toString();

                    String marcaCarro = lista.getSelectedItem().toString();

                    String litros = edtLitros.getText().toString();




                    SharedPreferences prefs = getSharedPreferences("dados", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();

                    editor.putString("marcaCarro", marcaCarro);
                    editor.putString("litros", litros);
                    editor.putString("combustivel", combustivel);
                    editor.apply();
                    Intent i = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(i);
                }
                else{
                    Toast.makeText(MainActivity.this, "TODOS OS CAMPOS DEVEM ESTAR PREENCHIDOS!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}